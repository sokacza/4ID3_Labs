AsyncAPDS9306
===========

Async library for APDS9306.

Useful to start measurement, do some another work, then get the result back when sensor has terminated.

Sync measurement provided too.

Developped with Avago datasheet AV02-4755EN_DS_APDS-9306_2016-10-21.pdf
